package ch09;

public class SimpleBean {
	private String name;
	private String id = "";
	private String message = "";
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name; //반환자
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message; //반환자
	}
	

}
